# Travex

This project is a smart tourism application, which focuses on getting users their preferred destinations and hotels in their budget.

## App Screenshots : 

<p>
  <img src="app_screenshots/Screenshot_20191006-080950.png" width="24%">
  <img src="app_screenshots/Screenshot_20191006-081223.png" width="24%">
  <img src="app_screenshots/Screenshot_20191006-081241.png" width="24%">
  <img src="app_screenshots/Screenshot_20191006-081252.png" width="24%">
  <img src="app_screenshots/Screenshot_20191006-081324.png" width="24%">
  <img src="app_screenshots/Screenshot_20191006-081344.png" width="24%">
  <img src="app_screenshots/Screenshot_20191006-081417.png" width="24%">
  <img src="app_screenshots/Screenshot_20191006-081432.png" width="24%">
  <img src="app_screenshots/Screenshot_20191006-081457.png" width="24%">
  <img src="app_screenshots/Screenshot_20191006-081535.png" width="24%">
  <img src="app_screenshots/Screenshot_20191006-081544.png" width="24%">
  <img src="app_screenshots/Screenshot_20191006-081550.png" width="24%">
</p>
