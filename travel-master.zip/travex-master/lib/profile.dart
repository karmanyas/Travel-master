import 'package:travex/attractions.dart';

class Profile{
  static List<Attraction> selectedAttractions = new List<Attraction>();
  static List<Attraction> selectedHotels = new List<Attraction>();
  static int budget;
  static int noOfDays;
  static int sumOfMoney;
}